# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

"""Inference Postprocessor init file."""

import sys
import os


sys.path.append(os.path.dirname(os.path.dirname(__file__)))
