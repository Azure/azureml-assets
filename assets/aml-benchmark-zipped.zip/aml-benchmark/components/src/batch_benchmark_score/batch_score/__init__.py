# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

"""Batch benchmark score init file."""
