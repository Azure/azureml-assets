# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

"""Parallel init file."""
