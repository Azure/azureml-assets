# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

"""Fake score script."""


def init():
    """Init method."""
    return


def run(raw_data):
    """Run method."""
    return {"0": "Answer 1"}
