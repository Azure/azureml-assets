# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

"""Batch score utilities init file."""
