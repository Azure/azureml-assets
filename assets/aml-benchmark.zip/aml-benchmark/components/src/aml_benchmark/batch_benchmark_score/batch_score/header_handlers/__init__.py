# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

"""OSS header handler init file."""
