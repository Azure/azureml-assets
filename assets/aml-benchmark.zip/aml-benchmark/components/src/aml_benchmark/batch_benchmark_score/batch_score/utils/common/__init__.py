# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

"""Batch common utilities init file."""
