# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

"""Online endpoint utils init file."""
