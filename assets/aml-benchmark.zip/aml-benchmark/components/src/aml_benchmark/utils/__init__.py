# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

"""utils init file."""
