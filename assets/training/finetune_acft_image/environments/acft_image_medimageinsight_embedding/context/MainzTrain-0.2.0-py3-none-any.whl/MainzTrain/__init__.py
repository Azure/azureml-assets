"""
The main entry point for training and evaluating models in MainzTrain is MainzTrain.PyLearn.

## Configuration

The configuration for training and evaluating is set by one or more YAML config files given to the `--conf_files` argument. A later config file can override previous config files if there are overlapping keywords. Any parameters can be further overridden or be added to the configuration using the command line argument `--config_overrides <a json style string containing a python dictionary>`.

### Description of a Config File

- `SAVE_TIMER_LOG`: Type `boolean`, default `False`. If `True`, save a timer log file for each rank in the save folder.
- `AUTOGRAD_PROFILER`: Type `boolean`, default `False`. If `True`, log `torch.autograd.profiler.profile` results.
- `CUDA`: Type `boolean`, default `True`. Use CUDA device or not.
- `LOG_GPU_MEM`: Type `boolean`, default `False`. Log GPU memory usage during training.
- `DEEPSPEED`: Type `boolean`, default `True`. Enable training with DeepSpeed or not.
- `FSDP_SETTING`: Including the following FSDP settings.
    - `MIXED_PRECISION` (FSDP): Type `boolean`. Enable mixed_precision for FSDP wrapping or not.
- `ZERO_STAGE`: Type `int`, default `0`. ZeRO optimization stage.
- `DEEPSPEED_CONFIG_OVERRIDES`: Type `dict`, optional. If specified, it adds to or overrides the DeepSpeed config derived from MainzTrain config. A key with `"::"` updates the object in the corresponding nested dict.
- `USE_HIT`: Type `boolean`, default `False`. If `True`, Use HiT with DeepSpeed. Only used when `DEEPSPEED` is `True`.
- `HIT_CONFIG`: Type `str`, required when `USE_HIT` is `True`. Path to the HiT config file. (To be deprecated and replaced by `HIT_CONFIG_DICT`.)
- `FP16`: Type `boolean`, default `False`. Enable FP16 training or not (Not used by FSDP).
- `BF16`: Type `boolean`, default `False`. Enable BF16 training or not (Not used by FSDP). Currently, this only works if DeepSpeed is enabled.
- `AMP`: Type `str`, default `'APEX'`. Choose among `'APEX'` and `'PYTORCH'`. If `'APEX'`, use APEX AMP for FP16, elif `'PYTORCH'`, use PyTorch native AMP. PyTorch native AMP is only available in `torch>=1.6.0`.
- `FP16_OPT_LEVEL`: Type `str`, default `"O1"`. APEX AMP FP16 optimization level. Only used when using APEX AMP for FP16.
- `DDP`: Type `str`, default `'PYTORCH'`. Choose among `'APEX'`, `'PYTORCH'`, and `'FSDP'`. If `'APEX'`, use APEX DDP, elif `'PYTORCH'`, use PyTorch DDP, elif `'FSDP'`, use FSDP. Only used when DeepSpeed is disabled.
- `EVALUATION_SPLITS`: Type `list[str]`, default `["dev" ,"test"]`. Splits of data that is used in evaluation.
- `START_LEARNING_RATE`: Type `float`, required. Learning rate.
- `GRADIENT_ACCUMULATE_STEP`: Type `int`, default `1`. Number of gradient accumulation steps.
- `GRAD_CLIPPING`: Type `float`, optional. Clipping gradients at `GRAD_CLIPPING`.
- `NO_AUTO_LR_SCALING`: Type `boolean`, default `False`. Disable automatic scaling of `START_LEARNING_RATE` by `world_size * GRADIENT_ACCUMULATE_STEP` or not.
- `BASENAME`: Type `str`. The basename for the run. Runs with the same basename are aggregated together with defferent run IDs. If it is not specified, and there is only one config file, the basename of the config file can be automatically used as `BASENAME`.
- `DATA_DIR`: Type `str`. The root path for loading data, model, additional configs. If it is not specified, and there is only one config file, the directory containing the config file can be automatically used as `DATA_DIR`.
- `SAVE_DIR`: Type `str`. The root path for saving checkpoints. If it is not specified, `DATA_DIR` is also used as `SAVE_DIR`. When using premium blob, `SAVE_DIR` must point to a folder that is being periodically cleaned up.
- `LOG_DIR`: Type `str` or `None` (with `'null'` as the value in the yaml file). The root path for saving logs and tensorboard logs. If it is not specified, `SAVE_DIR` is also used as `LOG_DIR`. If specified as `None`, no logs or tensorboard logs will be saved. `None` is useful when the training platform handles log streaming. Please do NOT use a blobfuse mounted folder for LOG_DIR.
- `COPY_BEST_CHECKPOINT`: Type `boolean`, default `True`. If `True`, the best checkpoint is copied to a `best_model_path` folder.
- `TASK`: Type `str`, required. Name of the task module and class this run is training/evaluating for.
- `SEED`: Type `int`, default `None`. Random seed. If specified, it is used as the seed for `random`, `np.random`, `torch`, and `torch.cuda`.
- `MAX_NUM_EPOCHS`: Type `int`, required. Total number of epochs for training.
- `MAX_OPTIM_STEPS`: Type `int`, default `-1`. Total number of optimization steps for training. If defined and not `-1`, `MAX_NUM_EPOCHS` will be ignored.
- `OPTIM_STEPS_PER_EPOCH`: Type `int`, required when using `iterators.CheckpointableIterator` for infinite batch generator. Number of optimization steps in one epoch.
- `OPTIMIZER`: Type `str`, required. Name of the optimizer to be used. Supported optimizers includes: PyTorch native optimizers, optimizers implemented in `MainzTrain.Models.Optimizers`, DeepSpeed native optimizers, and the custom optimizers provided under `--user_dir`.
- `OPTIMIZER_PARAMS`: Type `dict`, required. A dictionary containing any parameters of the selected `OPTIMIZER` excluding `params` and `lr`. `lr` is derived from `START_LEARNING_RATE`.
- `LR_SCHEDULER`: Type `str`, required. Name of the lr scheduler to be used. Supported lr schedulers includes: PyTorch native lr schedulers, lr schedulers implemented in `MainzTrain.Models.Optimizers`, DeepSpeed native lr schedulers, and the custom lr schedulers provided under `--user_dir`.
- `LR_SCHEDULER_PARAMS`: Type `dict`, required. A dictionary containing any parameters of the selected `LR_SCHEDULER` excluding `optimizer`.
- `LR_TRAINING_STEPS_NAME`: Type `str`, optional. Name of the parameter of the selected `LR_SCHEDULER` corresponding to the total training steps. This parameter is filled with proper value in the runtime.
- `RESUME`: Type `boolean`, default `False`. Resume from the latest checkpoint of a previous run with same `DATA_DIR` and `BASENAME`.
- `RESUME_FROM`: Type `str`, optional. If `True`, when `RESUME` is `False` or the resumption of the latest checkpoint fails, then resume from the provided path of checkpoint json file.
- `RESET_DATA_LOADER`: Type `boolean`, default `False`. When set to `True`, data loader will not be resumed from checkpoint when resuming.
- `SAVE_PER_OPTIM_STEPS`: Type `int`, optional. When it is conflict with "SAVE_STRATEGY", the priority of "SAVE_STRATEGY" will be higher than `SAVE_PER_OPTIM_STEPS`. If it is specified and is larger than 0, MainzTrain save a checkpoint every `SAVE_PER_OPTIM_STEPS` optimization steps. If it is 0 or is not specified, only save a checkpoint(and model) at the end of training or when getting a better evaluation score. If it is -1, only save the model with the best evaluation score. If it is -2, don't save any model.
- `EVAL_PER_OPTIM_STEPS`: Type `int`, optional. When it is conflict with "EVAL_STRATEGY", the priority of "EVAL_STRATEGY" will be higher than `EVAL_PER_OPTIM_STEPS`. If it is specified and is larger than 0, MainzTrain do an evaluation every `EVAL_PER_OPTIM_STEPS` optimization steps. If it is 0 or is not specified, do an evaluation when saving a checkpoint(or model). If it is -1, don't do any evaluation.
- `SAVE_STRATEGY`: Optional. Advance "checkpoint" and "model" saving strategy.  When it is conflict with "SAVE_PER_OPTIM_STEPS", the priority of "SAVE_STRATEGY" will be higher than `SAVE_PER_OPTIM_STEPS`. Including the following 2 settings:
    -`CHECKPOINT`: Optional. Advance config fields of "checkpoint" saving strategy, including the following:
        - `NAME`: Type `str`, required. The name of the strategy, currently only support the values:
            1. `PER_OPTIM_STEPS`, saving checkpoint every {SAVE_PER_OPTIM_STEPS} optimization steps, the additional settings for `PER_OPTIM_STEPS` is_`SAVE_PER_OPTIM_STEPS`, if `SAVE_PER_OPTIM_STEPS` is set and valid, the `NAME` can be default.
            2. `LAST`, save the last instance (of checkpoint) before the job finished, this is different from the n = 1 of strategy `save_last_n` -- which will delete the saved checkpoint when it exceed the limitation
            3. `BEST`, only save the model with the best evaluation score.
            4. `NO_SAVE`, don't save any checkpoint.
        - `SAVE_PER_OPTIM_STEPS`: Type `int`, optional. Only take effect when  value of `NAME` is `PER_OPTIM_STEPS`. Requirement >= 1. If it is not specified here, take the effect of `SAVE_PER_OPTIM_STEPS`, if both of them was not set, only save a checkpoint at the end of training.
        - `KEEP_LAST_N`, Type `int`,  optional. Only take effect when  value of `NAME` is `PER_OPTIM_STEPS`. Requirement >= 1. Only maintain up to {KEEP_LAST_N} saved instance in the memory, which is the latest N instance, If it is not specified, keep all the saved instance. only valid when the value >= 1,
        Here is a example settings (save checkpoint every 100 optim_steps but only keep at most 8 latest checkpoint in storage):
            SAVE_STRATEGY:
                CHECKPOINT:
                    NAME: 'PER_OPTIM_STEPS'
                    SAVE_PER_OPTIM_STEPS: 100
                    KEEP_LAST_N: 8
            or
            SAVE_STRATEGY:
                CHECKPOINT:
                    SAVE_PER_OPTIM_STEPS: 100
                    KEEP_LAST_N: 8
    - `MODEL`: Optional. Advance config fields of  "model" saving strategy, including the following:
        - `NAME`: Type `str`, required. The name of the strategy, currently only support:
            1. `PER_OPTIM_STEPS`, saving model every {SAVE_PER_OPTIM_STEPS} optimization steps, the additional settings for `PER_OPTIM_STEPS` is `SAVE_PER_OPTIM_STEPS`, if `SAVE_PER_OPTIM_STEPS` is set and valid, the `NAME` can be default
            2. `LAST`, save the last instance (of model) before the job finished, this is different from the n = 1 of strategy `save_last_n` -- which will delete the saved model when it exceed the limitation
            3. `BEST`, only save the model with the best evaluation score.
            4. `NO_SAVE`, don't save any model.
        - `SAVE_PER_OPTIM_STEPS`:  Type `int`, optional. Only take effect when  value of `NAME` is `PER_OPTIM_STEPS`. Requirement >= 1. If it is not specified here, take the effect of `SAVE_PER_OPTIM_STEPS`, if both of them were not set,  only save a checkpoint at the end of training.
        - `KEEP_LAST_N`: Type `int`,  optional. Only take effect when  value of `NAME` is `PER_OPTIM_STEPS`. Requirement >= 1. Only maintain up to {KEEP_LAST_N} saved instance in the memory, which is the latest N instance, If it is not specified, keep all the saved instance. only valid when the value >= 1,
        Here is a example settings (save the last model before the job finished):
             SAVE_STRATEGY:
                MODEL:
                    NAME: 'LAST'
- `EVAL_STRATEGY`: Optional. Advance evaluation strategy. When it is conflict with "EVAL_PER_OPTIM_STEPS", the priority of "EVAL_STRATEGY" will be higher than `EVAL_PER_OPTIM_STEPS`. Tt Includes the following settings:
    - `NAME`: Type `str`, required. the name of the strategy, currently only support the values:
        1. `PER_OPTIM_STEPS`, doing evaluation every {EVAL_PER_OPTIM_STEPS} optimization steps, the additional settings for `eval_per_optim_steps` is `EVAL_PER_OPTIM_STEPS`, if `EVAL_PER_OPTIM_STEPS` is set and valid, the `NAME` can be default:
        2. `SAVED_CHECKPOINT`, do an evaluation when saving a checkpoint.
        3. `SAVED_MODEL`, do an evaluation when saving a model.
        4. `SAVED_CHECKPOINT_AND_MODEL`, do an evaluation when saving a checkpoint or saving a model.
        5. `NO_EVAL`, don't do evaluation.
     - `EVAL_PER_OPTIM_STEPS`: Type `int`, optional. Only take effect when  value of `NAME` is `PER_OPTIM_STEPS`. Requirement >= 1. If it is not specified, do an evaluation when saving a checkpoint.
     Here is a example settings (evaluate every 5000 optim_steps):
        EVAL_STRATEGY:
            NAME: 'PER_OPTIM_STEPS'
            EVAL_PER_OPTIM_STEPS: 5000

- `LOG_FIRST`: Type `int`, default `10`. Number of optimization steps at the beginning of training to be logged.
- `LOG_EVERY`: Type `int`, default `100`. Number of optimization steps between logs.
- `OFFICIAL`: Type `boolean`, default `False`. When in `OFFICIAL` mode, only error messages are logged.
- `DEBUG`: Type `boolean`, default `False`. When in `DEBUG` mode, all messages are logged. In normal mode (`OFFICIAL` and `DEBUG` are both `False`), rank 0 will log messages above or equal to `logging.INFO` level, and other ranks will log messages above or equal to `logging.WARNING` level.
- `LOGLEVEL_OVERRIDE`: type `str` or `int`. This could be used to write directly the log level. This parameter accepts either a string or an integer as defined in the Python API: https://docs.python.org/3/library/logging.html#levels
- `WEIGHT_SMOOTHING`: Type `dict`, optional. A dictionary with the following keys to set weight smoothing:
    - `'decay'`: Type `float` in range `(0, 1)`, required. Decay parameter controling exponential smoothing of model parameters.
    - `'use_cpu'`: Type `boolean`, default `False`. If `True`, maintain smoothed model weights on CPU, otherwise, on same device as the models.
    - `'ref_batch_size'`: Type `Tuple[str, int]`, optional. A tuple of the reference batch size name and value.
    - `'eval_smoothed_weight'`: Type `boolean`, default `False`. If `True`, during training, evaluate both the models and the smoothed models, during evaluation, load only the smoothed models.
- `PYLEARN_MODEL`: Type `str`, required for evaluation. This points to a checkpoint folder saved by MainzTrain to be evaluated.
- `MIN_CHECKPOINT`, `MAX_CHECKPOINT`: Type `int`. If provided, `PYLEARN_MODEL` should point to the `SAVE_DIR` of the job to be evaluated. We scan and evaluate all the checkpoints in the subfolders in format of `"run_X/XXXX"` under `PYLEARN_MODEL`, with `XXXX` being a decimal number between `MIN_CHECKPOINT` and `MAX_CHECKPOINT`.
- `DONT_LOAD_MODEL`: Type `boolean`, default `False`. When this is true, it does not load the model weights in PYLEARN_MODEL for evaluation.
- `AML_DO_NOT_LOG`: Type `list[str]` or `str`, default `[]`. List of metric names or regex pattern of metric names to not be logged to AML.
- `ORT_EXPERT_PARALLEL_SIZE`: Type `int`, default `world_size`. Only used with ORT DDP mode for ORT MoE models, to tell the `ort_ddp_grid` what is the expert parallel size.
- `DEBUG_DUMP_TRACEBACKS_INTERVAL`: Type `int`, default `0`. This debugging feature allows the user to dump the tracebacks of all threads of the main process to disk at regular intervals. The given value specifies the interval in seconds. A value of `0` deactivates the feature. The tracebacks are written to files `tracebacks_rank.txt` (where rank is the GPU rank) in the same directory as the logs. This feature is useful to learn where the execution gets stuck when a job is hanging. The feature only works within the main process and is not automatically applied to subprocesses. If you want to dump tracebacks from subprocesses, you have to manually register the corresponding faulthandler in those subprocesses (see https://docs.python.org/3/library/faulthandler.html#faulthandler.dump_traceback_later). To get correct tracebacks when working with CUDA operations (which are generally asynchronous), it is recommended to set the environment variable `CUDA_LAUNCH_BLOCKING=1` on all nodes before starting the training script. Please be aware that a short interval might create very large traceback files for long running jobs.
- `NO_MPI_ABORT`: Type `boolean`, default `False`. By default, the trainer will call `MPI_Abort()` to kill all processes in a distributed job when one of the processes fails. If it is set to `True`, `MPI_Abort()` will not be called, and the job will be left hanging.
- `NEBULA_CHECKPOINTING`: Type boolean, default `False`. Due to asynchronously persisting checkpoint, NEBULA_CHECKPOINTING can only be used when: 1.SAVE_PER_OPTIM_STEPS > 0, 2. SAVE_STRATEGY.CHECKPOINT.NAME is 'PER_OPTIM_STEPS’ and SAVE_STRATEGY.CHECKPOINT.SAVE_PER_OPTIM_STEPS > 0, and SAVE_STRATEGY.CHECKPOINT.KEEP_LAST_N was not set and 3. COPY_BEST_CHECKPOINT is false. When it is true, trainer will leverage Nebula service to save the checkpoint asynchronously. When it is`False`, the trainer will save and load checkpoint with torch.save() and torch.load(). The Nebula service can be leverage with `torch_nebula` library, which can help saving and loading checkpoint in a large sacle distributed job with high throughput. Install `torch_nebula` package with: `pip install torch_nebula==0.1.0.dev417 -f https://nebulapackagestorage.blob.core.windows.net/dev-package/nebula_dev.html`. Considering that Nebula have its data format (partition) to maintain checkpoints, So the Nebula persisted checkpoint can only be loaded with Nebula, while the torch.save checkpoint can only be loaded by torch.load.  the "NEBULA_CHECKPOINTING" flag automatically added during the training process in the *_checkpoint.json will help MainzTrainer decide the way to load the checkpoint.
- `NEBULA_PERSISTENT_TIME_INTERVAL`: Type `int`, default is 60 (seconds), `torch_nebula` backend will follow this interval to periodically move the checkpoint from the cache storage to the `SAVE_DIR`. Recommend to set this interval smaller than the save interval in training process to make sure every checkpoint will be persisted eventually.
- `ADD_SIFT`: Type `boolean`, default `False`. This enables SIFT training, as implemented in the DeBERTa model. When enabled, please specify the following arguments too:
    - `SIFT_HIDDEN_SIZE`: corresponds to the embedding hidden size (integer).
    - `SIFT_TARGET_MODULE` (defaults to embeddings.LayerNorm): Corresponds to the final module that is called after the embeddings are computed in the model. SIFT uses this to understand where to apply the noised input in the network. For example, the default value `embeddings.LayerNorm` works for HuggingFace's Bert models, where the [LayerNorm module](https://github.com/huggingface/transformers/blob/b5e2b183af5e40e33a4dc7659e697d137259d56e/src/transformers/models/bert/modeling_bert.py#L177) is applied at the [end of the forward](https://github.com/huggingface/transformers/blob/b5e2b183af5e40e33a4dc7659e697d137259d56e/src/transformers/models/bert/modeling_bert.py#L221), "embeddings" comes from the [attribute name of the BertEmbeddings object in the BertModel](https://github.com/huggingface/transformers/blob/b5e2b183af5e40e33a4dc7659e697d137259d56e/src/transformers/models/bert/modeling_bert.py#L865). You will need to change this value for different models.
    - `SIFT_LEARNING_RATE` (default 1e-4): The learning rate to update the perturbation.
    - `SIFT_INIT_PERTURBATION` (default 1e-2): The initial range of perturbation.

    SIFT also requires the task to implement the following methods:
    - `sift_logits_fn`: This method works as callback to perform a forward pass, called from SIFT. The batch will be stored in `*wargs`, so you can extract it and compute the forward pass as you would in `forward_func`.
        ```
        def sift_logits_fn(self, model, batch):
            data, target = batch
            return model(data)
        ```
    - `sift_extract_logits`: This method receives the same `*wargs` and `*kwargs` objects that are passed to a criteria call (which typically contains the logits and the targets, this is controlled by you in `forward_func`). It needs to return only the logits of the model.
        ```
        def sift_extract_logits(self, *wargs, **kwargs):
            output, target = wargs
            return output
        ```
    Finally, SIFT requires access to the batch in order to compute the perturbation. To enable this, decorate your `forward_func` method with `MainzTrain.Models.SIFT import setup_forward_func_sift.setup_forward_func_sift`, this will allow the SIFT criteria to temporarily have access to the batch. The `forward_func` method is the method that is the first argument that is passed to the trainer `forward_pass` method. Refer to the `MainzTrainer` `forward_pass` docstring for more information, and check the example on `MnistTask.py`. You can optionally not apply SIFT by looking a batch. To do so, you can do: `@setup_forward_func_sift(use_sift_func=lambda batch: batch['sift_compatible'] is True)`.

Other keywords may need to be added to the config depending on the implementation of the chosen `TASK` and other modules the `TASK` uses.

## Training

To train a model in MainzTrain execute PyLearn as follows:

`python -m MainzTrain.PyLearn train --conf_files <conf_file_path> [<conf_file_path> ...]`

Each execution will generate a run_id folder in `<SAVE_DIR>/<BASENAME>_conf~`, containing a copy of configs, logs and trained models. The folder `best_model` contains the best performing model in the dev set, a copy of the configuration used for training, and the scores on the dev set.

## Evaluation

To evaluate a model previously trained in MainzTrain execute PyLearn as follows:

`python -m MainzTrain.PyLearn evaluate --conf_files <conf_file_path> [<conf_file_path> ...]`

Each execution will generate a run_id folder in `<SAVE_DIR>/<BASENAME>_conf~`, containing a copy of configs and a file called `scores.json` which contains the final score information for both dev and test sets.

## Training and evaluation in one shot

To train a model and run evaluation using the best performing model in the dev set (using languages on the 'DEV_LANG' argument) execute PyLearn as follows:

`python -m MainzTrain.PyLearn train-and-evaluate --conf_files <conf_file_path> [<conf_file_path> ...]`

Each execution will generate a run_id folder in `<SAVE_DIR>/<BASENAME>_conf~`, containing a copy of configs, logs and trained models. The folder `best_model` contains the best performing model in the dev set, a copy of the configuration used for training, and the scores on the dev set.

## Overriding configs in command lines

`--config_overrides <json style string of a python dictionary>` can be used to override any config parameter, e.g. `--config_overrides {"<PARAM_NAME_1>": <PARAM_VALUE_1>, "<PARAM_GROUP_2>.<PARAM_SUBGROUP_2>.<PARAM_2>": <PARAM_VALUE_2>}`. A key with "." updates the object in the corresponding nested dict. Remember to escape `"` in command line.

## Using tasks (models, criteria), optimizers, and lr schedulers defined in a user folder:

`--user_dir <path_to_user_dir>` can be used to provide `MainzTrainer` a user folder containing user defined tasks (models, criteria), optimizers, and lr schedulers.
The folder should have the following structure:

```
.
+-- __init__.py
+-- Tasks
|   +-- __init__.py
|   +-- MyCustomTask.py
+-- Optimizers
|   +-- __init__.py
|   +-- MyCustomOptimizer.py
|   +-- MyCustomLrScheduler.py
+-- Networks
|   +-- __init__.py
|   +-- MyCustomModel.py
+-- Criteria
|   +-- __init__.py
|   +-- MyCustomCriterion.py
```

## Using multiple GPUs

MainzTrain leverages [OpenMPI](https://www.open-mpi.org/) to scale to multiple gpus and multiple nodes seamlessly. To use multiple gpus available in a single node, all you need to do is to run MainzTrain as follows:

`mpirun -np <number of gpus> python -m MainzTrain.PyLearn <...rest of commands explained above>`

"""

from .__about__ import __version__  # noqa: F401
