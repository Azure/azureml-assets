import os
import time

def check_for_preemption_signal():
    signal_path = "/tmp/SingularityPreemptionSignal"
    if os.path.exists(signal_path):
        print("Preemption signal detected.")
        return True
    return False

def send_preemption_signal_ack():
    ack_path = "/tmp/SingularityPreemptionSignalAck"
    try:
        # Create the preemption acknowledgment file
        with open(ack_path, "w") as ack_file:
            ack_file.write("Preemption acknowledgment sent.")
        print("Preemption acknowledgment sent.")
        while True:
            time.sleep(60)
            print("Waiting for preemption.")
    except Exception as e:
        print(f"Error sending preemption acknowledgment: {e}")
