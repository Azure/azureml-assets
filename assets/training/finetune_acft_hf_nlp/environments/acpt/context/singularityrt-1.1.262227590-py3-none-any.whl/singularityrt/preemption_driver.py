import os
import time
import subprocess
import argparse
import platform

signal_path = "/tmp/SingularityPreemptionSignal"
ack_path = "/tmp/SingularityPreemptionSignalAck"

# Function to send preemption signal
def send_preemption_signal(): 
    try:
        # Create the preemption signal file
        print("Sending preemption signal...")
        time.sleep(2)
        with open(signal_path, "w") as signal_file:
            signal_file.write("Preemption signal")
        print(f"Preemption signal sent.")
    except Exception as e:
        print(f"Error sending preemption signal: {e}")

# Function to wait for preemption acknowledgment
def wait_for_preemption_ack(timeout):
    timeout = int(timeout)
    print(f"Waiting for preemption acknowledgment for {timeout} seconds...")
    start_time = time.time()

    while time.time() - start_time < timeout:
        print("Waiting for preemption acknowledgment...")
        if os.path.exists(ack_path):
            print(f"Preemption acknowledgment received")
            os.remove(ack_path)
            return True

        time.sleep(2)

    print(f"Preemption acknowledgment not received within {timeout} seconds.")
    return False

# Function to kill a process
def kill_process(pid):
    try:
        if platform.system() == "Windows":
            print(f'Killing process {pid}...')
            subprocess.run(['taskkill', '/PID', str(pid), '/F', '/T'])
        elif platform.system() in ["Linux", "Darwin"]:  # Darwin is MacOS
            subprocess.run(['kill', str(pid)])
        else:
            raise NotImplementedError(f"Platform {platform.system()} not supported")
    except Exception as e:
        print(f'Error killing process {pid}: {e}')

# Driver function
def run_driver(pids=[], timeout=120):
    send_preemption_signal()
    # Wait for preemption acknowledgment
    result = wait_for_preemption_ack(timeout)

    if result:
        print("Preemption acknowledgment received successfully, Job can now be preempted.")
    else:
        print("Failed to receive preemption acknowledgment within the timeout.")

    if os.path.exists(signal_path):
        os.remove(signal_path)
    if os.path.exists(ack_path):
        os.remove(ack_path)

    for pid in pids:
        kill_process(pid)

